package test;

import org.junit.Assert;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.skyscreamer.jsonassert.JSONParser;
import org.json.JSONString;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONString;

import pojoclasses.Coordinates;
import pojoclasses.Customer;
import util.JsonReader;
import util.OutputHelper;

public class CustomerServiceTest {
	
	@SuppressWarnings("deprecation")
	@Test
	public void shouldCalculateCorrectDistance() {
		
		//Given
		double latitude = 52.986375;
		double longitude = -6.043701;
		double result = 41.768784505523335;
		
		//When
		Coordinates other = new Coordinates(latitude,longitude);
		Coordinates DublinCordinates = new Coordinates(53.339428d, -6.257664d);
		
		//Then
		Assert.assertEquals(result, other.distanceWithRespectToOtherCoordinate(DublinCordinates),0.000000002 );
		
		
	}
	
	@Test
	public void shouldValidateJSON() {
		
		JsonReader reader = new JsonReader();
		try {
			InputStream inpStream = new FileInputStream("./inputFile/customers.txt");
			List<Object> customerList = reader.parseAsStream(inpStream, Customer.class);
			Assert.assertTrue(customerList != null);

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		
		

	}
	
	@Test
	public void shouldValidateJSONString() {
		
		String actual = "{\"latitude\": \"52.986375\", \"user_id\": 12, \"name\": \"Christina McArdle\", \"longitude\": \"-6.043701\"}";
		JSONAssert.assertEquals(
		  "{\"latitude\": \"52.986375\",\"longitude\": \"-6.043701\"}", actual, JSONCompareMode.LENIENT);

	}
	
	
	
}